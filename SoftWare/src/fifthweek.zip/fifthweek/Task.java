package fifthweek;

public class Task {
	int time=0;
}
